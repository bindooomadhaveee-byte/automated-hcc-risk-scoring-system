# Automated HCC Risk Scoring System

A complete, production-ready web application for CMS-HCC risk scoring, RAF calculation, and patient risk management — built with pure HTML, CSS, and JavaScript (no build tools required).

---

## Project Structure

```
hcc-risk-system/
├── index.html              ← Main dashboard
├── css/
│   └── style.css           ← Global dark-theme styles
├── js/
│   ├── data.js             ← HCC data, ICD mappings, utilities
│   └── dashboard.js        ← Dashboard charts & table logic
└── pages/
    ├── patients.html       ← Patient management & enrollment
    ├── scoring.html        ← Individual RAF score breakdown
    ├── icd-mapper.html     ← ICD-10 → HCC code lookup tool
    ├── reports.html        ← Population analytics & charts
    └── settings.html       ← System configuration
```

---

## Features

### Dashboard (`index.html`)
- Live KPI cards: total patients, high-risk count, average RAF, coding gaps
- Sortable/searchable patient risk queue table
- RAF score distribution bar chart
- Top HCC categories horizontal chart
- Monthly RAF trend line chart (average + high-risk)
- Click-through patient detail modal

### Patients (`pages/patients.html`)
- Full patient roster with risk badges
- **New patient enrollment form** with automatic RAF calculation
- ICD-10 code entry → auto-maps to HCC categories
- Demographic RAF scoring (CMS-HCC v28 age/gender bands)
- Delete patient with confirmation

### Risk Scoring (`pages/scoring.html`)
- Select any patient to load their full score breakdown
- Per-component RAF: demographic + chronic + interaction
- Doughnut chart of RAF composition
- Bar chart of HCC weight contributions
- Add new ICD-10 codes and immediately recalculate RAF
- Coding gap alerts panel
- Print/export button

### ICD-10 Mapper (`pages/icd-mapper.html`)
- Single code lookup with HCC mapping result card
- Bulk code entry (comma or newline separated)
- Shows total RAF sum for a bulk code set
- Full HCC reference table (CMS-HCC v28, 60+ categories)
- Searchable HCC reference with RAF weights

### Reports (`pages/reports.html`)
- Population summary: total cost projection, risk distribution
- Doughnut chart: risk level distribution
- Percentile chart: RAF score distribution
- Top 10 HCC frequency chart
- Full patient summary table with cost estimates
- Print/export to PDF via browser

### Settings (`pages/settings.html`)
- User profile management
- Scoring model selection (CMS-HCC v28/v24/ESRD)
- Configurable risk thresholds (High/Moderate/Low)
- Cost multiplier setting
- Export all patient data as JSON
- Import patient data from JSON
- Reset to sample data

---

## How to Run

1. **Download and unzip** the project folder
2. **Open `index.html`** directly in any modern browser  
   *(Chrome, Firefox, Edge, Safari — no server needed)*
3. Patient data is stored in **localStorage** — persists across sessions

> No installation, no npm, no build tools required.

---

## Technology Stack

| Layer | Technology |
|-------|-----------|
| UI Framework | Vanilla HTML5 + CSS3 |
| Charts | Chart.js 4.4 (CDN) |
| Fonts | Google Fonts (Syne + DM Sans + IBM Plex Mono) |
| Data Storage | Browser localStorage |
| Icons | Inline SVG |
| Scoring Model | CMS-HCC v28 (2024) |

---

## HCC Scoring Model

This system implements **CMS-HCC Model v28** used by Medicare Advantage plans for risk adjustment:

**RAF Score = Demographic Score + Chronic Disease Score + Interaction Score**

- **Demographic Score**: Age band × gender weight (from CMS v28 tables)
- **Chronic Disease Score**: Sum of all mapped HCC RAF weights
- **Interaction Score**: Additional weight for disease combinations

**Risk Levels:**
- High Risk: RAF ≥ 2.0
- Moderate Risk: RAF 1.2 – 1.99
- Low Risk: RAF < 1.2

**Cost Estimation:** RAF Score × $9,800 per member per year (configurable)

---

## Included ICD-10 → HCC Mappings

70+ ICD-10 codes covering:
- Diabetes (Type 1, Type 2, with/without complications)
- Cardiovascular (Heart failure, Afib, MI, vascular disease)
- COPD and respiratory conditions
- Chronic kidney disease (Stages 1–5, dialysis)
- Mental health (Depression, schizophrenia, bipolar)
- Oncology (Various cancer categories)
- Neurological (MS, Parkinson's, epilepsy)
- Rheumatological (RA, inflammatory arthritis)
- HIV/AIDS, liver disease, skin conditions

---

## Extending the System

To add more ICD-10 mappings, edit `js/data.js`:
```javascript
const ICD_TO_HCC = {
  // Add your mappings here:
  "YOUR_ICD": "HCC XX",
};
```

To add more HCC categories:
```javascript
const HCC_CATEGORIES = {
  "HCC XX": { desc: "Condition name", raf: 0.XXX },
};
```
